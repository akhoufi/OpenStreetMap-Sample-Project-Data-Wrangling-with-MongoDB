GeoPostcodes Geographic database
Copyright (C) 2014 GeoData Ltd

www.geopostcodes.com
info@geopostcodes.com


========================
= WWW.GEOPOSTCODES.COM =
========================

Thank you for buying a GeoPostcodes product, we appreciate your business.

This archive contains the following files:

ReadMe.txt	This file
Version.txt	Database version and export date
License.pdf	Terms and conditions of use
Product.pdf	The product description
DataSpecs.pdf	Database tables and fields specification
ASC/*		Database in ASC text format
CSV/*		Database in CSV text format
KML/*		Database in KML geographic format
Shapefile/*	Database in ESRI Shapefile geographic format
Resources/*	Additional resources files
